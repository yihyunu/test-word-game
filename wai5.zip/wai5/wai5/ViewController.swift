//
//  ViewController.swift
//  testing
//
//  Created by 이현우 on 2017. 6. 20..
//  Copyright © 2017년 Plumhyunu. All rights reserved.
//

import UIKit
import Foundation
import MobileCoreServices
import CoreData

extension Array
{
    /** Randomizes the order of an array's elements. */
    mutating func shuffle()
    {
        for _ in 0..<10
        {
            sort { (_,_) in arc4random() < arc4random() }
        }
    }
}
// random


class ViewController: UIViewController {
    
    /// CoreData connection variable
    let coreDataDB = (UIApplication.shared.delegate as! AppDelegate).managedObjectContext
    
    
    /// TableView array data
    var items = [Item]()
    
    @IBOutlet weak var lblChar1: UILabel!
    @IBOutlet weak var lblChar2: UILabel!
    @IBOutlet weak var lblChar3: UILabel!
    @IBOutlet weak var lblChar4: UILabel!
    @IBOutlet weak var lblChar5: UILabel!
    @IBOutlet weak var lblChar6: UILabel!
    @IBOutlet weak var lblChar7: UILabel!
    @IBOutlet weak var lblChar8: UILabel!
    @IBOutlet weak var lblTyped: UILabel!
    @IBOutlet weak var quizPhotoView: UIImageView!
    
    var quizWord = "apple" //self.items[0].name
    var limitRe:Int = 0
    var cards: [Character] = []


    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // Load CoreData data
        items = Item.fetchAll(coreDataDB)




        var countText: Int = (quizWord.characters.count) - 1
        for _ in 0...countText
        {let index1 = quizWord.index(quizWord.startIndex, offsetBy: limitRe)
            
            cards.append(quizWord[index1])
            limitRe = limitRe + 1
        }
        cards.shuffle()
        quizPhotoView.image = UIImage(named: "1.jpg")

        if countText >= 0 {lblChar1.text = "\(cards[0])"} else {lblChar1.text = ""}
        if countText >= 1 {lblChar2.text = "\(cards[1])"} else {lblChar2.text = ""}
        if countText >= 2 {lblChar3.text = "\(cards[2])"} else {lblChar3.text = ""}
        if countText >= 3 {lblChar4.text = "\(cards[3])"} else {lblChar4.text = ""}
        if countText >= 4 {lblChar5.text = "\(cards[4])"} else {lblChar5.text = ""}
        if countText >= 5 {lblChar6.text = "\(cards[5])"} else {lblChar6.text = ""}
        if countText >= 6 {lblChar7.text = "\(cards[6])"} else {lblChar7.text = ""}
        if countText >= 7 {lblChar8.text = "\(cards[7])"} else {lblChar8.text = ""}
  

        
    
        

        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.

    }

    @IBAction func butChar1(_ sender: UIButton) {
    if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
        lblTyped.text = lblTyped.text! + lblChar1.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar2(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar2.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar3(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar3.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar4(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar4.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar5(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar5.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar6(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar6.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar7(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar7.text!
    if lblTyped.text == quizWord {lblTyped.text = "Good"}}
    @IBAction func butChar8(_ sender: UIButton) {
        if (lblTyped.text!.characters.count) > (quizWord.characters.count) - 1 {lblTyped.text = ""}
    lblTyped.text = lblTyped.text! + lblChar8.text!
        if lblTyped.text == quizWord {lblTyped.text = "Good"}
    }
    
}

