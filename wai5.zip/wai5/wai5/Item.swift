//
//  Item.swift
//  iOS-Swift-TableView-CoreData-Example
//
//  Created by Diego Rossini Vieira on 9/7/15.
//  https://github.com/diegorv/iOS-Swift-TableView-CoreData-Example
//

import Foundation
import CoreData

// MODEL
class Item: NSManagedObject {

  @NSManaged var name: String

  /// Function to initialize a new Item
  convenience init(name: String, inManagedObjectContext managedObjectContext: NSManagedObjectContext) {
    let entity = NSEntityDescription.entity(forEntityName: "Item", in: managedObjectContext)!
    self.init(entity: entity, insertInto: managedObjectContext)
    self.name = name
  }

  /// Function to get all CoreData values
  ///
  /// - parameter managedObjectContext: CoreData Connection
  ///
  class func fetchAll(_ managedObjectContext: NSManagedObjectContext) -> [Item] {
    let listagemCoreData             = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")

    // Sort alphabetical by field "name"
    let orderByName                  = NSSortDescriptor(key: "name", ascending: true, selector: #selector(NSString.caseInsensitiveCompare(_:)))
    listagemCoreData.sortDescriptors = [orderByName]

    // Get items from CoreData
    return (try? managedObjectContext.fetch(listagemCoreData)) as? [Item] ?? []
  }

  /// Function to search item by name
  ///
  /// - parameter name: Item name
  /// - parameter managedObjectContext: CoreData Connection
  ///
  class func search(_ name: String, inManagedObjectContext managedObjectContext: NSManagedObjectContext) -> Item? {
    let fetchRequest       = NSFetchRequest<NSFetchRequestResult>(entityName: "Item")
    fetchRequest.predicate = NSPredicate(format: "name = %@", name)

    let result             = (try? managedObjectContext.fetch(fetchRequest)) as? [Item]
    return result?.first
  }

  /// Function to check duplicate item
  ///
  /// - parameter name: Item name
  /// - parameter managedObjectContext: CoreData Connection
  ///
  class func checkDuplicate(_ name: String, inManagedObjectContext managedObjectContext: NSManagedObjectContext) -> Bool {
    return search(name, inManagedObjectContext: managedObjectContext) != nil
  }

  /// Function to delete a item
  ///
  /// - parameter managedObjectContext: CoreData Connection
  ///
  func destroy(_ managedObjectContext: NSManagedObjectContext) {
    managedObjectContext.delete(self)
  }

  /// Function to save CoreData values
  ///
  /// - parameter managedObjectContext: CoreData Connection
  ///
  func save(_ managedObjectContext: NSManagedObjectContext) {
    do {
      try managedObjectContext.save()
    }
    catch {
      let nserror = error as NSError
      print("Error on save: \(nserror.debugDescription)")
    }
  }
}
